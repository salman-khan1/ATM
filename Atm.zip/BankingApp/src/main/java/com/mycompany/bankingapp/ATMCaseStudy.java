/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bankingapp;

/**
 *
 * @author hraza
 */
public class ATMCaseStudy {
// main method creates and runs the ATM
 public static void main( String[] args )
 {
 ATM theATM = new ATM();
 theATM.run();
 } // end main    
}
